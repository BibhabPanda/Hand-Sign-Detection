# File: real_time_detection.py
import cv2
import numpy as np
from cvzone.HandTrackingModule import HandDetector
from tensorflow.keras.models import load_model
from sklearn.preprocessing import LabelEncoder

# Load the trained model
model = load_model("asl_model.h5")

# Load label encoder
le = LabelEncoder()
le.classes_ = np.load("label_encoder.npy")

# Initialize camera and hand detector
cap = cv2.VideoCapture(0)
detector = HandDetector(maxHands=1)

while True:
    success, img = cap.read()
    hands, img = detector.findHands(img)

    if hands:
        hand = hands[0]
        x, y, w, h = hand['bbox']
        imgCrop = img[y - 20:y + h + 20, x - 20:x + w + 20]  # Crop hand region
        imgCrop = cv2.resize(imgCrop, (200, 200))  # Resize to 200x200
        imgCrop = np.expand_dims(imgCrop, axis=0)  # Add batch dimension

        # Predict the gesture
        prediction = model.predict(imgCrop)
        predicted_class = np.argmax(prediction)
        predicted_label = le.inverse_transform([predicted_class])[0]

        # Display the result
        cv2.putText(img, f"Prediction: {predicted_label}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    cv2.imshow("Image", img)
    if cv2.waitKey(1) & 0xFF == ord("q"):  # Press 'q' to quit
        break

cap.release()
cv2.destroyAllWindows()
