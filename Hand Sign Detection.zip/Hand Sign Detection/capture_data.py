# File: capture_data.py
import cv2
import os
from cvzone.HandTrackingModule import HandDetector

# Initialize camera and hand detector
cap = cv2.VideoCapture(0)
detector = HandDetector(maxHands=1)

# Create folder to save images
folder = "Data/A"  # Change "A" to the label you're capturing (e.g., "B", "C", etc.)
if not os.path.exists(folder):
    os.makedirs(folder)

counter = 0

while True:
    success, img = cap.read()
    hands, img = detector.findHands(img)

    if hands:
        hand = hands[0]
        x, y, w, h = hand['bbox']
        imgCrop = img[y - 20:y + h + 20, x - 20:x + w + 20]  # Crop hand region
        imgCrop = cv2.resize(imgCrop, (200, 200))  # Resize to 200x200

        cv2.imshow("ImageCrop", imgCrop)
        cv2.imshow("Image", img)

    key = cv2.waitKey(1)
    if key == ord("s"):  # Press 's' to save image
        counter += 1
        cv2.imwrite(f'{folder}/Image_{counter}.jpg', imgCrop)
        print(f"Saved Image {counter}")

    if key == ord("q"):  # Press 'q' to quit
        break

cap.release()
cv2.destroyAllWindows()
