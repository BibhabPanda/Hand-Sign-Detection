# File: preprocess_data.py
import numpy as np
import cv2
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# Load images and labels
data = []
labels = []
for label in os.listdir("Data"):
    for img_path in os.listdir(f"Data/{label}"):
        img = cv2.imread(f"Data/{label}/{img_path}")
        img = cv2.resize(img, (200, 200))  # Resize to 200x200
        img = img / 255.0  # Normalize pixel values
        data.append(img)
        labels.append(label)

# Convert to numpy arrays
data = np.array(data)
labels = np.array(labels)

# Encode labels (e.g., A=0, B=1, ...)
le = LabelEncoder()
labels = le.fit_transform(labels)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, random_state=42)

# Save preprocessed data
np.save("X_train.npy", X_train)
np.save("X_test.npy", X_test)
np.save("y_train.npy", y_train)
np.save("y_test.npy", y_test)
np.save("label_encoder.npy", le.classes_)

print("Data preprocessing complete!")
